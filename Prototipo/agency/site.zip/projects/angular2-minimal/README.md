This is a minimal modification of the Angular 2 Quick Start environment
that demonstrates how to show a GoJS diagram in a component.

First, assuming you already have npm:
```
$ npm update
```

Note how we have updated the <code>src/systemjs.config.json</code> file to tell which GoJS library to load.

Start app page with:
```
$ npm start
```
